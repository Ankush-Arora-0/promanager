



export default function Div(){
    return(
        <>
        
     <section className="w3l-breadcrumb">
        <div className="container d-flex justify-content-center align-items-center vh-100"> 
            <div className="row "> 
                <div className="col-lg-8">
                       <div className="twice-two text-center   " >
                             HI THERE WELCOME TO MY PAGE !!!!<br/>
                             Cypher Task Innovate
                       </div>
               </div>
           </div>
        </div>
    </section>
  
  
        
        </>
    )
}